// 1. Import express and axios
import express from "express";
import axios from "axios";

const app = express();
const port = 3000;

// 2. Set the view engine to EJS
app.set('view engine', 'ejs');

// 3. Use the public folder for static files.
app.use(express.static("public"));

// 4. When the user goes to the home page it should render the index.ejs file.
app.get("/", async (req, res) => {
    try {
        const response = await axios.get('https://v2.jokeapi.dev/joke/Any');
        const joke = response.data.joke ? response.data : { setup: response.data.setup, delivery: response.data.delivery };
        res.render('index', { joke });
    } catch (error) {
        console.log(error.response ? error.response.data : error.message);
        res.status(500).send('Something went wrong!');
    }
});

// 6. Listen on your predefined port and start the server.
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
